import warnings
import torch
import yaml
import cv2
import os
import shutil
import sys
import numpy as np
import matplotlib.pyplot as plt
from tqdm import trange
from PIL import Image
from ultralytics.nn.tasks import attempt_load_weights
from ultralytics.utils.torch_utils import intersect_dicts
from ultralytics.utils.ops import xywh2xyxy, non_max_suppression
from pytorch_grad_cam import GradCAMPlusPlus, GradCAM, XGradCAM, EigenCAM, HiResCAM, LayerCAM, RandomCAM, EigenGradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image, scale_cam_image
from pytorch_grad_cam.activations_and_gradients import ActivationsAndGradients
from pathlib import Path

# 忽略警告
warnings.filterwarnings('ignore')
warnings.simplefilter('ignore')

# 设置随机种子
np.random.seed(0)


# 图像预处理函数
def letterbox(im, new_shape=(640, 640), color=(114, 114, 114), auto=True, scaleFill=False, scaleup=True, stride=32):
    shape = im.shape[:2]  # current shape [height, width]
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:  # only scale down, do not scale up (for better val mAP)
        r = min(r, 1.0)

    ratio = r, r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
    if auto:  # minimum rectangle
        dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding
    elif scaleFill:  # stretch
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)  # add border
    return im, ratio, (dw, dh)


# 激活和梯度提取类
class ActivationsAndGradients:
    def __init__(self, model, target_layers, reshape_transform):
        self.model = model
        self.gradients = []
        self.activations = []
        self.reshape_transform = reshape_transform
        self.handles = []
        for target_layer in target_layers:
            self.handles.append(
                target_layer.register_forward_hook(self.save_activation))
            self.handles.append(
                target_layer.register_forward_hook(self.save_gradient))

    def save_activation(self, module, input, output):
        activation = output
        if self.reshape_transform is not None:
            activation = self.reshape_transform(activation)
        self.activations.append(activation.cpu().detach())

    def save_gradient(self, module, input, output):
        if not hasattr(output, "requires_grad") or not output.requires_grad:
            return

        def _store_grad(grad):
            if self.reshape_transform is not None:
                grad = self.reshape_transform(grad)
            self.gradients = [grad.cpu().detach()] + self.gradients

        output.register_hook(_store_grad)

    def post_process(self, result):
        logits_ = result[:, 4:]
        boxes_ = result[:, :4]
        sorted, indices = torch.sort(logits_.max(1)[0], descending=True)
        return torch.transpose(logits_[0], dim0=0, dim1=1)[indices[0]], torch.transpose(boxes_[0], dim0=0, dim1=1)[
            indices[0]]

    def __call__(self, x):
        self.gradients = []
        self.activations = []
        model_output = self.model(x)
        post_result, pre_post_boxes = self.post_process(model_output[0])
        return [[post_result, pre_post_boxes]]


# yolov8模型的目标处理类
class yolov8_target(torch.nn.Module):
    def __init__(self, ouput_type, conf, ratio, end2end) -> None:
        super().__init__()
        self.ouput_type = ouput_type
        self.conf = conf
        self.ratio = ratio
        self.end2end = end2end

    def forward(self, data):
        post_result, pre_post_boxes = data
        result = []
        for i in trange(int(post_result.size(0) * self.ratio)):
            if (self.end2end and float(post_result[i, 0]) < self.conf) or (
                    not self.end2end and float(post_result[i].max()) < self.conf):
                break
            if self.ouput_type == 'class' or self.ouput_type == 'all':
                if self.end2end:
                    result.append(post_result[i, 0])
                else:
                    result.append(post_result[i].max())
            elif self.ouput_type == 'box' or self.ouput_type == 'all':
                for j in range(4):
                    result.append(pre_post_boxes[i, j])
        return sum(result)


# yolov8热力图生成类
class yolov8_heatmap:
    def __init__(self, weight, device, method, layer, backward_type, conf_threshold, ratio, show_box, renormalize):
        device = torch.device(device)
        ckpt = torch.load(weight)
        model_names = ckpt['model'].names
        model = attempt_load_weights(weight, device)
        model.info()
        for p in model.parameters():
            p.requires_grad_(True)
        model.eval()

        if not hasattr(model, 'end2end'):
            model.end2end = False

        target = yolov8_target(backward_type, conf_threshold, ratio, model.end2end)
        target_layers = [model.model[l] for l in layer]
        method = eval(method)(model, target_layers, use_cuda=device.type == 'cuda')
        method.activations_and_grads = ActivationsAndGradients(model, target_layers, None)

        colors = np.random.uniform(0, 255, size=(len(model_names), 3)).astype(np.int32)
        self.__dict__.update(locals())

    def post_process(self, result):
        result = non_max_suppression(result, conf_thres=self.conf_threshold, iou_thres=0.65)[0]
        return result

    def draw_detections(self, box, color, name, img):
        xmin, ymin, xmax, ymax = list(map(int, list(box)))
        # 定义英文到中文的类别映射字典
        class_name_map = {
            'Bacterial_spot': '细菌斑点病',
            'Early_blight': '早疫病',
            'Late_blight': '晚疫病',
            'Leaf_Mold': '叶霉病',
            'Septoria_leaf_spot': '叶斑病',
            'Spider_mites Two-spotted_spider_mite': '蜘蛛螨损害',
            'Tomato_Yellow_Leaf_Curl_Virus': '黄化曲叶病毒病',
            'Tomato__healthy': '健康叶片'
        }

        # 在 name 字符串中查找匹配的英文类名并替换成中文
        name_in_chinese = name
        for english_name, chinese_name in class_name_map.items():
            if english_name in name:  # 如果在name中找到了对应的英文名
                name_in_chinese = name.replace(english_name, chinese_name)
                break  # 找到第一个匹配的即可替换，跳出循环

        # 获取文本的尺寸，避免文本超出框外
        font_scale = 2
        thickness = 2
        text_size, _ = cv2.getTextSize(name_in_chinese, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
        text_width, text_height = text_size

        # 如果文本过大，减小字体，直到文本适应框内
        while text_width > (xmax - xmin - 20):  # 20是为了留出一定的边距
            font_scale -= 0.1
            text_size, _ = cv2.getTextSize(name_in_chinese, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
            text_width, text_height = text_size

        # 绘制边界框
        cv2.rectangle(img, (xmin, ymin), (xmax, ymax), tuple(int(x) for x in color), 2)

        # 在框内绘制文本
        text_x = xmin + 10
        text_y = ymin + text_height + 10  # 调整文本位置，避免与框重叠

        # 设置红色字体 (BGR: 0, 0, 255)
        text_color = (255, 0, 0)

        # 绘制文本
        cv2.putText(img, name_in_chinese, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, font_scale,
                    text_color, thickness, lineType=cv2.LINE_AA)

        return img

    def renormalize_cam_in_bounding_boxes(self, boxes, image_float_np, grayscale_cam):
        renormalized_cam = np.zeros(grayscale_cam.shape, dtype=np.float32)
        for x1, y1, x2, y2 in boxes:
            x1, y1 = max(x1, 0), max(y1, 0)
            x2, y2 = min(grayscale_cam.shape[1] - 1, x2), min(grayscale_cam.shape[0] - 1, y2)
            renormalized_cam[y1:y2, x1:x2] = scale_cam_image(grayscale_cam[y1:y2, x1:x2].copy())
        renormalized_cam = scale_cam_image(renormalized_cam)
        eigencam_image_renormalized = show_cam_on_image(image_float_np, renormalized_cam, use_rgb=True)
        return eigencam_image_renormalized

    def process(self, img_path, save_path):
        img = cv2.imread(img_path)
        img = letterbox(img)[0]
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = np.float32(img) / 255.0
        tensor = torch.from_numpy(np.transpose(img, axes=[2, 0, 1])).unsqueeze(0).to(self.device)

        try:
            grayscale_cam = self.method(tensor, [self.target])
        except AttributeError as e:
            return

        grayscale_cam = grayscale_cam[0, :]
        cam_image = show_cam_on_image(img, grayscale_cam, use_rgb=True)

        pred = self.model(tensor)[0]
        if not self.model.end2end:
            pred = self.post_process(pred)
        else:
            pred = pred[0][pred[0, :, 4] > self.conf_threshold]
        if self.renormalize:
            cam_image = self.renormalize_cam_in_bounding_boxes(pred[:, :4].cpu().detach().numpy().astype(np.int32), img,
                                                               grayscale_cam)
        if self.show_box:
            for data in pred:
                data = data.cpu().detach().numpy()
                cam_image = self.draw_detections(data[:4], self.colors[int(data[5])],
                                                 f'{self.model_names[int(data[5])]} {float(data[4]):.2f}', cam_image)

        cam_image = Image.fromarray(cam_image)
        cam_image.save(save_path)

        # 如果置信度满足条件，则拷贝原始文件，后缀改为 .png
        if len(pred) > 0:  # 置信度过滤后的目标存在
            output_image_copy_path = os.path.join(
                os.path.dirname(save_path),  # 保存到与热力图相同的目录
                f"{os.path.splitext(os.path.basename(img_path))[0]}.png"  # 修改后缀为 .png
            )
            shutil.copy(img_path, output_image_copy_path)  # 拷贝源文件

    def __call__(self, img_path, save_path):
        if os.path.isdir(img_path):
            # 遍历文件夹中的图片
            for img_path_ in os.listdir(img_path):
                full_img_path = os.path.join(img_path, img_path_)
                if os.path.isfile(full_img_path):  # 确保是文件
                    # 构建热力图的目标路径
                    output_image_path = os.path.join(save_path, img_path_)  # 保持原始文件名
                    self.process(full_img_path, output_image_path)  # 处理并保存图片
        else:
            # 如果是单张图片，直接保存
            output_image_path = os.path.join(save_path, os.path.basename(img_path))  # 保持原文件名
            self.process(img_path, output_image_path)  # 处理并保存图片


def get_params():
    params = {
        'weight': r"runs\detect\train_yolov8s_CBAM_4\weights\best.pt",
        'device': 'cuda:0',
        'method': 'GradCAM',
        'layer': [0],
        'backward_type': 'all',
        'conf_threshold': 0.2,
        'ratio': 0.02,
        'show_box': True,
        'renormalize': False
    }
    return params


def process_images_in_directory(directory_path):
    image_files = [f for f in Path(directory_path).rglob('*.JPG')]  # 可以选择其他格式

    model = yolov8_heatmap(**get_params())

    for image_file in image_files:
        output_path = r"F:\Course\6_datasets\4_tomato_已合并_未标注\未改名\img_out"
        model(image_file, output_path)


if __name__ == '__main__':
    directory = r'F:\Course\6_datasets\4_tomato_已合并_未标注\未改名\xie'
    process_images_in_directory(directory)
