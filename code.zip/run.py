import itertools
import os
import pandas as pd
from ultralytics import YOLO


class Combination:
    def __init__(self, data, epochs, batch, yaml):
        self.data = data
        self.epochs = epochs
        self.batch = batch
        self.yaml = yaml


if __name__ == '__main__':
    # 定义参数组合
    data = [r'data\merge\data.yaml', r'data\original\data.yaml']
    epochs = [5, 10]
    batch = [1, 3]
    yaml = ['yolov8s-cbam.yaml', 'yolov8s.yaml']

    # 生成所有可能的组合
    all_combinations = list(itertools.product(data, epochs, batch, yaml))

    # 使用集合去除重复项
    unique_combinations = set(all_combinations)

    # 将结果转换为类存储的形式
    combination_objects = []
    for combination in unique_combinations:
        combination_obj = Combination(combination[0], combination[1], combination[2], combination[3])
        combination_objects.append(combination_obj)

    # 创建一个空的DataFrame来存储数据
    df = pd.DataFrame(columns=["Name", "Precision", "Recall", "mAP", "mAP@0.5", "Precision(B)", "Recall(B)"])

    # 打印转换后的结果
    print("转换后的结果:")
    for obj in combination_objects:
        name = 'train-{}-epochs({})-batch({})-cbam({})'.format(
            "merge" if 'merge' in obj.data else "original",
            obj.epochs, obj.batch, 'cbam' in obj.yaml
        )

        # 判断目录是否存在
        directory_path = os.path.join(os.getcwd(), 'runs/detect', name)
        if not os.path.exists(directory_path):
            model = YOLO(obj.yaml).load('yolov8s.pt')  # build from YAML and transfer weights
            results = model.train(
                **{'name': name, 'data': obj.data, 'epochs': obj.epochs, 'batch': obj.batch, 'amp': False,
                   'resume': True}
            )

        pt_file_address = r"runs\detect\{}\weights\best.pt".format(name)  # 需要修改的地址
        model = YOLO(pt_file_address)
        metrics = model.val()

        # 运行上面代码结束后，在下面其实已经给出了相应p、r、map
        # 在路径下会有val文件夹，里面会有各种曲线图
        # print(metrics)  #查看metrics的所有存储内容
        print("Precision:", metrics.box.p)
        print("Recall:", metrics.box.r)
        print("mAP:", metrics.box.map)
        print("mAP@0.5:", metrics.box.map50)
        print("Precision(B):", metrics.results_dict['metrics/precision(B)'])
        print("Recall(B):", metrics.results_dict['metrics/recall(B)'])

        # 将结果添加到DataFrame中
        new_row = pd.DataFrame({
            "Name": [name],
            "Precision": [metrics.box.p],
            "Recall": [metrics.box.r],
            "mAP": [metrics.box.map],
            "mAP@0.5": [metrics.box.map50],
            "Precision(B)": [metrics.results_dict['metrics/precision(B)']],
            "Recall(B)": [metrics.results_dict['metrics/recall(B)']],
        })
        df = pd.concat([df, new_row], ignore_index=True)

        print("=======================================================================================================")

    # 将DataFrame写入Excel文件
    df.to_excel("metrics_results.xlsx", index=False)

    # Load a model
    # model = YOLO('yolov8s.yaml')  # build a new model from YAML
    # model = YOLO('yolov8s.pt')  # load a pretrained model (recommended for training)
    # model = YOLO('yolov8s-cbam.yaml').load('yolov8s.pt')  # build from YAML and transfer weights

    # Train the model
    # results = model.train(**{'data': r'data\merge\data.yaml', 'epochs': 5, 'batch': 1, 'amp': False})

    # 多GPU训练
    # # Load a model
    # model = YOLO('yolov8n.pt')  # load a pretrained model (recommended for training)
    # # Train the model with 2 GPUs
    # results = model.train(data='coco128.yaml', epochs=100, imgsz=640, device=[0, 1])

    # 恢复中断的训练
    # from ultralytics import YOLO
    # # Load a model
    # model = YOLO('path/to/last.pt')  # load a partially trained model
    # # Resume training
    # results = model.train(resume=True)
