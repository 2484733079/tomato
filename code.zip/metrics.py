from ultralytics import YOLO

if __name__ == '__main__':
    # name = 'train_yolov8s_CBAM_4'

    # # 从零开始重新训练模型
    # model = YOLO('yolov8s-CBAM-Backbone.yaml')  # Build from YAML without pre-trained weights
    # results = model.train(
    #     **{'name': name,
    #        'data': 'data\\merge911\\data.yaml',  # 数据配置文件路径
    #        'epochs': 20,  # 训练轮数
    #        'batch': 6,    # 批量大小
    #        'amp': False,  # 禁用自动混合精度
    #        'resume': False,  # 不从检查点恢复训练
    #        'pretrained': False
    #        }
    # )

    # 评价模型
    # pt_file_address = r"runs\detect\{}\weights\best.pt".format(name)  # 需要修改的地址
    # model = YOLO(pt_file_address)
    # metrics = model.val()  # 在执行这一行的时候，系统会自动找你训练时候的yaml，若报错，看报错提示，需要将yaml放在对应位置
    # 运行上面代码结束后，在下面其实已经给出了相应p、r、map
    # 在路径下会有val文件夹，里面会有各种曲线图
    # print(metrics)  # 查看metrics的所有存储内容
    # print("Precision:", metrics.box.p)
    # print("Recall:", metrics.box.r)
    # print("mAP:", metrics.box.map)
    # print("mAP@0.5:", metrics.box.map50)
    # print("precision(B):", metrics.results_dict['metrics/precision(B)'])
    # print("recall(B):", metrics.results_dict['metrics/recall(B)'])

    # 导出模型
    # pt_file_address = r"runs\detect\{}\weights\best.pt".format(name)  # 需要修改的地址
    # model = YOLO(pt_file_address)
    # model.export(format="onnx", simplify=True, opset=12)

    # # 加载模型
    # model = YOLO(r"runs\detect\{}\weights\best.pt".format(name))
    # img = (r"F:\Course\6_datasets\5_tomato_已合并_已标注\guo1\0_0bc63b4c-e41b-4338-a8ac-af664048fdbb___Leaf_Mold + 1_0a4b3cde-c83a-4c83-b037-010369738152___Late_blight + 2_6ff464c8-6ac2-451e-99e4-6135aecf869d___Septoria_leaf_spot.jpg")
    # result = model.predict(source=img, save=True, conf=0.7)

    from ultralytics import YOLO
    from PIL import Image, ImageDraw, ImageFont
    import os
    import cv2
    import numpy as np

    name = 'train_yolov8s'

    # 病害名称字典
    disease_names = {
        0: "细菌斑点病",
        1: "早疫病",
        2: "晚疫病",
        3: "叶霉病",
        4: "叶斑病",
        5: "蜘蛛螨损害",
        6: "靶斑病",
        7: "黄化曲叶病毒病",
        8: "番茄花叶病毒病",
        9: "健康叶片",
    }

    # 病害颜色字典（BGR 格式）
    disease_colors = {
        0: (255, 0, 0),  # 红色
        1: (0, 255, 0),  # 绿色
        2: (0, 0, 255),  # 蓝色
        3: (0,0,205),  # 黄色
        4: (255, 0, 255),  # 紫色
        5: (0, 255, 255),  # 青色
        6: (128, 0, 128),  # 紫色
        7: (128, 128, 0),  # 橄榄色
        8: (0, 128, 128),  # 深青色
        9: (128, 128, 128),  # 灰色
    }

    # 设置文件地址和模型
    pt_file_address = r"runs\detect\{}\weights\best.pt".format(name)
    model = YOLO(pt_file_address)

    # 预测文件夹中的图片
    results = model.predict(
        source="C:\\Users\\Administrator\\Desktop\\新建文件夹",  # 替换为你的图片文件夹路径
        save=True,  # 保存预测结果
        conf=0.2,  # 置信度阈值
        device="0",  # 使用 "0" 或 "cuda" 指定GPU
        show=False,  # 是否实时显示结果（适用于Jupyter）
    )

    # 加载字体
    font = ImageFont.truetype("SimHei.ttf", size=20)  # 字体文件路径和大小

    # 遍历每张图片的结果
    for i, result in enumerate(results):
        # 获取原始图像并转换为 PIL 格式
        image_bgr = result.orig_img  # OpenCV 格式（BGR）
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)  # 转换为 RGB 格式
        image = Image.fromarray(image_rgb)  # 转换为 PIL 图像
        draw = ImageDraw.Draw(image)

        # 遍历检测结果
        for box in result.boxes:
            # 获取检测框坐标
            x1, y1, x2, y2 = map(int, box.xyxy[0])

            # 获取类别和置信度
            cls = int(box.cls)
            conf = float(box.conf)

            # 获取病害名称
            disease_name = disease_names.get(cls, "未知病害")

            # 获取病害颜色
            color = disease_colors.get(cls, (0, 0, 0))  # 默认黑色

            # 自定义标签内容
            label = f"{disease_name} {conf:.2f}"

            # 绘制检测框
            draw.rectangle([x1, y1, x2, y2], outline=color, width=4)

            # 绘制标签
            draw.text((x1, y1 - 20), label, fill=color, font=font)

        # 保存图像
        output_path = os.path.join("C:\\Users\\Administrator\\Desktop\\YOLO", f"output_{i}.jpg")
        image.save(output_path)
        print(f"保存结果到: {output_path}")

    # # 自定义保存逻辑
    # output_dir = os.path.join("runs", "detect", "predict_custom")  # 自定义输出目录
    # os.makedirs(output_dir, exist_ok=True)
    #
    # for result in results:
    #     # 获取当前图片所有检测框的置信度
    #     confidences = result.boxes.conf.tolist()
    #
    #     # 判断条件：置信度数量 ≥ 3 且 所有置信度 ≥ 0.85
    #     if len(confidences) >= 3 and all(conf >= 0.9 for conf in confidences):
    #         # 获取源文件名称（不含路径）
    #         source_filename = os.path.basename(result.path)
    #
    #         # 构建保存路径（使用源文件名称）
    #         save_path = os.path.join(output_dir, source_filename)
    #
    #         # 保存带标注的图片
    #         result.save(filename=save_path)
    #         print(f"✅ 已保存符合条件的结果：{save_path}")
    #     else:
    #         print(f"❌ 跳过不符合条件的结果：{result.path}（检测到 {len(confidences)} 个目标）")

    # import os
    # import os.path
    #
    # # 设置文件夹路径
    # folder_1 = r"F:\Course\6_datasets\5_tomato_已合并_已标注\1_YOLOv8s_CBAM"  # 作为参考的图片文件夹
    # folder_2 = r"F:\Course\6_datasets\5_tomato_已合并_已标注\2_YOLOv8s"  # 需要删除的文件夹
    # folder_3 = r"F:\Course\6_datasets\5_tomato_已合并_已标注\3_SSD"  # 需要删除的文件夹
    # folder_4 = r"F:\Course\6_datasets\5_tomato_已合并_已标注\4_FasterRCNN"  # 需要删除的文件夹
    #
    # # 获取 `1_YOLOv8s_CBAM` 文件夹中的所有图片文件名（去除后缀名）
    # images_in_folder_1 = set(os.path.splitext(image)[0] for image in os.listdir(folder_1))
    #
    #
    # # 定义一个函数，用来删除不在参考文件夹中的图片（只比较文件名，不比较后缀）
    # def delete_non_matching_images(source_folder, reference_images):
    #     # 遍历源文件夹，删除不在参考文件夹中的图片
    #     for image_name in os.listdir(source_folder):
    #         # 获取去除后缀的文件名
    #         image_base_name = os.path.splitext(image_name)[0]
    #         if image_base_name not in reference_images:
    #             image_path = os.path.join(source_folder, image_name)
    #             os.remove(image_path)
    #             print(f"已删除：{image_name}")
    #
    #
    # # 删除 `2_YOLOv8s`、`3_SSD` 和 `4_FasterRCNN` 文件夹中不在 `1_YOLOv8s_CBAM` 中的图片
    # delete_non_matching_images(folder_2, images_in_folder_1)
    # delete_non_matching_images(folder_3, images_in_folder_1)
    # delete_non_matching_images(folder_4, images_in_folder_1)
    #
    # print("删除完成！")
